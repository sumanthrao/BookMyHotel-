
<?php include('header.php'); ?>
<html>
<body><br>
<h1>We Have Many exciting offers and packages</h1>
<h3>Use The folowing PROMO Codes to Avail exciting offers
</h3><div>
<table width="1300" cellpadding="10" cellspacing="15">
<tr>
<th width="250"></th>

</th><th>PROMO CODE<th>
<th></th>
<th></th><th>OFFERS</th>
<th></th>
<th></th></tr>
<tc>
<tr><th></th><th>NEW10<th>
<th></th>
<th></th><th>Avail 10% OFF on selected hotels</th>
<th></th>
<th></th></tr>
<tr><th></th><th>BM20<th>
<th></th>
<th></th><th>Get 20% OFF on beach hotels</th>
<th></th>
<th></th></tr>
<tr><th></th><th>BF100<th>
<th></th>
<th></th><th>GET free food coupons for breakfast on booking a tour package</th>
<th></th>
<th></th></tr>
<tr><th></th><th>CT100<th>
<th></th>
<th></th><th>GET free accomodation on booking all india tour packages</th>
<th></th>
<th></th></tr>
<tr><th></th><th>BE100<th>
<th></th>
<th></th><th>GET free food coupons on booking a tour package</th>
<th></th>

</table></div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include('footer.php'); ?>
<body></html>