<html><body><div>
            <div id="About us">
                <h3 style="text-align:center">
                    < This Website is developed by /><br>
                    < Sumanth ,Sumeet and Srinivas />
                    < Pesu CSE />  
                </h3><br><br>
                <h3 style="text-align:center">
                    About Us
                </h3><br>
                <p>
                    We Offer service in <br>
                    <ul><li>Travels</li>
                    <li>Hotels</li>
                    <li>Tourist packages</li>
                    <li>Homestays</li>
                    <li>Foreign trips</li>
                    <li>Foreign hotels</li></ul>
                </p>
                </div>
<br>
            <div id="footer" style="margin-top:50px">
                <p><a href="cancellation.php" style="color:grey;text-decoration:none;margin-top:10%;">Privacy Policy</a></p>
            </div><script>
            </body>
            </html>